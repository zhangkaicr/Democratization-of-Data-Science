# MI Long Bootstrap Pooling Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** 构建一个可复用的 R 函数，接收 `mice::complete(imp, "long")` 产生的长表数据，对用户自定义的单一数值统计量进行 bootstrap 估计，并按 Rubin 法则合并得到点估计、标准误与 Rubin t 区间。

**Architecture:** 采用单文件函数实现加单文件验证脚本的最小结构。主函数负责校验 `long` 数据、按 `.imp` 自动拆分完整数据集、排除 `.imp = 0`，再对每个完整数据集执行 bootstrap，并由内部辅助函数完成重抽样与 Rubin 标量合并，最后返回带中间结果的结构化列表。

**Tech Stack:** R, dplyr, purrr, tibble, stats, mice

---

### Task 1: 写 `long` 数据接口的失败测试

**Files:**
- Modify: `c:\Users\85330\Desktop\MI_any\tests\test_pool_mi_param_boot.R`

- [ ] **Step 1: 写失败测试**

```r
# 载入待测试函数文件；此时接口尚未改为 long 版，因此测试应先失败
source("R/pool_mi_param_boot.R")

# 构造一个包含 .imp 的 long 数据，并故意保留 .imp = 0
long_dat <- data.frame(
  y = c(1, 2, 3, 4, 10, 20, 30, 40, 11, 21, 31, 41),
  grp = c(0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1),
  .imp = c(0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2),
  .id = as.character(rep(1:4, 3))
)

# 定义自定义统计量函数；输入数据集，输出均值差
stat_fun <- function(dat) {
  mean(dat$y[dat$grp == 1]) - mean(dat$y[dat$grp == 0])
}

# 运行主函数
res <- pool_mi_boot_long(
  data_long = long_dat,
  n_boot = 20,
  stat_fun = stat_fun,
  seed = 2026,
  show_progress = FALSE
)

# 基本结构断言
stopifnot(is.list(res))
stopifnot(all(c(
  "pooled_estimate",
  "pooled_se",
  "conf_low",
  "conf_high",
  "within_variance",
  "between_variance",
  "total_variance",
  "per_imputation"
) %in% names(res)))

# 数值关系断言
stopifnot(length(res$per_imputation) == 2)
stopifnot(is.finite(res$pooled_estimate))
stopifnot(is.finite(res$pooled_se))
stopifnot(res$total_variance >= res$within_variance)
stopifnot(res$conf_low <= res$pooled_estimate)
stopifnot(res$conf_high >= res$pooled_estimate)

cat("test_pool_mi_boot_long: PASS\n")
```

- [ ] **Step 2: 运行测试确认失败**

Run: `Rscript --version`
Expected: 输出 R 版本信息

Run: `Rscript tests/test_pool_mi_param_boot.R`
Expected: FAIL，并提示 `pool_mi_boot_long` 未定义或参数接口不匹配

- [ ] **Step 3: 提交**

```bash
git add tests/test_pool_mi_param_boot.R
git commit -m "test: add failing test for MI Rubin bootstrap pooling"
```

### Task 2: 实现 `long` 数据接口主函数

**Files:**
- Create: `c:\Users\85330\Desktop\MI_any\R\pool_mi_param_boot.R`
- Test: `c:\Users\85330\Desktop\MI_any\tests\test_pool_mi_param_boot.R`

- [ ] **Step 1: 写最小实现**

```r
validate_long_input <- function(data_long) {
  if (!inherits(data_long, c("data.frame", "tbl_df"))) {
    stop("`data_long` 必须是 data.frame 或 tibble。", call. = FALSE)
  }
  if (!(".imp" %in% names(data_long))) {
    stop("`data_long` 必须包含 `.imp` 列。", call. = FALSE)
  }
}

split_long_by_imp <- function(data_long) {
  data_long |>
    dplyr::filter(.data$.imp > 0) |>
    dplyr::group_split(.data$.imp, .keep = TRUE)
}

resample_rows_default <- function(data) {
  data |>
    dplyr::slice_sample(n = nrow(data), replace = TRUE)
}

estimate_one_imputation_boot <- function(data, n_boot, stat_fun, resample_fun = NULL) {
  sampler <- resample_fun %||% resample_rows_default
  boot_values <- purrr::map_dbl(seq_len(n_boot), function(i) {
    tryCatch(stat_fun(sampler(data)), error = function(e) NA_real_)
  })
  boot_values_ok <- boot_values[is.finite(boot_values)]
  list(
    .imp = dplyr::first(data$.imp),
    estimate = mean(boot_values_ok),
    variance = stats::var(boot_values_ok),
    boot_se = stats::sd(boot_values_ok),
    boot_values = boot_values,
    n_success = sum(is.finite(boot_values)),
    n_failed = sum(!is.finite(boot_values))
  )
}

rubin_pool_scalar <- function(estimates, variances, conf_level = 0.95, n, k = 1) {
  m <- length(estimates)
  pooled_estimate <- mean(estimates)
  within_variance <- mean(variances)
  between_variance <- stats::var(estimates)
  total_variance <- within_variance + (1 + 1 / m) * between_variance
  pooled_se <- sqrt(total_variance)
  r <- ((1 + 1 / m) * between_variance) / within_variance
  df_old <- (m - 1) * (1 + 1 / r)^2
  lambda <- (r + 2 / ((n - k) + 3)) / (r + 1)
  df_observed <- (((n - k) + 1) / ((n - k) + 3)) * (n - k) * (1 - lambda)
  df <- (df_old * df_observed) / (df_old + df_observed)
  alpha <- 1 - conf_level
  t_crit <- stats::qt(1 - alpha / 2, df = df)
  statistic <- pooled_estimate / pooled_se
  p_value <- 2 * stats::pt(abs(statistic), df = df, lower.tail = FALSE)
  list(
    pooled_estimate = pooled_estimate,
    pooled_se = pooled_se,
    conf_low = pooled_estimate - t_crit * pooled_se,
    conf_high = pooled_estimate + t_crit * pooled_se,
    statistic = statistic,
    p_value = p_value,
    df = df,
    within_variance = within_variance,
    between_variance = between_variance,
    total_variance = total_variance
  )
}

`%||%` <- function(x, y) if (is.null(x)) y else x

pool_mi_boot_long <- function(data_long, n_boot, stat_fun, seed = NULL,
                              show_progress = TRUE, conf_level = 0.95,
                              resample_fun = NULL) {
  validate_long_input(data_long)
  if (!is.null(seed)) {
    set.seed(seed)
  }
  completed_list <- split_long_by_imp(data_long)
  per_imputation <- purrr::map(
    completed_list,
    ~ estimate_one_imputation_boot(.x, n_boot = n_boot, stat_fun = stat_fun, resample_fun = resample_fun)
  )
  estimates <- vapply(per_imputation, function(x) x$estimate, numeric(1))
  variances <- vapply(per_imputation, function(x) x$variance, numeric(1))
  n <- nrow(completed_list[[1]])
  pooled <- rubin_pool_scalar(estimates, variances, conf_level, n, k = 1)
  c(
    pooled,
    list(
      m = length(completed_list),
      n_boot = n_boot,
      per_imputation = per_imputation
    )
  )
}
```

- [ ] **Step 2: 运行测试确认通过**

Run: `Rscript --version`
Expected: 输出 R 版本信息

Run: `Rscript tests/test_pool_mi_param_boot.R`
Expected: PASS，并输出 `test_pool_mi_boot_long: PASS`

- [ ] **Step 3: 提交**

```bash
git add R/pool_mi_param_boot.R tests/test_pool_mi_param_boot.R
git commit -m "feat: implement MI Rubin bootstrap pooling function"
```

### Task 3: 强化输入检查与 `.imp = 0` 排除逻辑

**Files:**
- Modify: `c:\Users\85330\Desktop\MI_any\R\pool_mi_param_boot.R`
- Test: `c:\Users\85330\Desktop\MI_any\tests\test_pool_mi_param_boot.R`

- [ ] **Step 1: 追加失败测试**

```r
# 追加在现有测试脚本末尾

error_caught <- FALSE
tryCatch({
  pool_mi_boot_long(
    data_long = data.frame(y = 1:4),
    n_boot = 20,
    stat_fun = stat_fun,
    show_progress = FALSE
  )
}, error = function(e) {
  error_caught <<- TRUE
})

stopifnot(isTRUE(error_caught))
cat("single_imputation_error_check: PASS\n")
```

- [ ] **Step 2: 运行测试确认失败**

Run: `Rscript tests/test_pool_mi_param_boot.R`
Expected: FAIL，因为当前实现尚未对缺失 `.imp` 列做显式报错

- [ ] **Step 3: 写最小增强实现**

```r
if (!is.function(stat_fun)) {
  stop("`stat_fun` 必须是函数。", call. = FALSE)
}

if (!is.numeric(n_boot) || length(n_boot) != 1L || is.na(n_boot) || n_boot < 2) {
  stop("`n_boot` 必须是不小于 2 的单个数值。", call. = FALSE)
}

if (length(completed_list) < 2) {
  stop("排除 `.imp = 0` 后，至少需要 2 个插补数据集。", call. = FALSE)
}
```

- [ ] **Step 4: 运行测试确认通过**

Run: `Rscript tests/test_pool_mi_param_boot.R`
Expected: PASS，并额外输出 `single_imputation_error_check: PASS`

- [ ] **Step 5: 提交**

```bash
git add R/pool_mi_param_boot.R tests/test_pool_mi_param_boot.R
git commit -m "feat: add validation for MI Rubin bootstrap pooling"
```

### Task 4: 补充 `mice + complete(long)` 示例脚本

**Files:**
- Create: `c:\Users\85330\Desktop\MI_any\tests\example_pool_mi_param_boot.R`

- [ ] **Step 1: 写示例脚本**

```r
source("R/pool_mi_param_boot.R")

library(mice)

set.seed(42)
n <- 100
dat <- data.frame(
  x = rnorm(n),
  z = rnorm(n)
)
dat$y <- 0.5 + 0.8 * dat$x - 0.3 * dat$z + rnorm(n, sd = 1)
dat$x[sample.int(n, 15)] <- NA

imp <- mice(dat, m = 3, maxit = 1, printFlag = FALSE, seed = 42)
dat_long <- complete(imp, "long", include = TRUE)

stat_fun <- function(dat_one) {
  fit <- lm(y ~ x + z, data = dat_one)
  unname(stats::coef(fit)[["x"]])
}

res <- pool_mi_boot_long(
  data_long = dat_long,
  n_boot = 50,
  stat_fun = stat_fun,
  seed = 99,
  show_progress = FALSE
)

print(res$pooled_estimate)
print(res$pooled_se)
print(c(res$conf_low, res$conf_high))
```

- [ ] **Step 2: 运行示例确认可执行**

Run: `Rscript tests/example_pool_mi_param_boot.R`
Expected: 输出有限数值的合并点估计、标准误和区间

- [ ] **Step 3: 提交**

```bash
git add tests/example_pool_mi_param_boot.R
git commit -m "docs: add runnable example for MI Rubin bootstrap pooling"
```
