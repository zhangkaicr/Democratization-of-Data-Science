# 基于 MICE Long 数据的 Bootstrap + Rubin 合并函数设计文档

## 1. 目标

设计一个通用 `R` 函数，用于接收 `mice::complete(imp, "long")` 生成的纵向堆叠完整数据，对用户自定义的单一数值统计量进行 bootstrap 估计，并最终使用 Rubin 法则合并得到：

- 合并后的点估计
- 组内方差
- 组间方差
- 总方差
- 合并标准误
- Barnard-Rubin 调整自由度
- t 统计量
- p 值
- 置信区间

该函数应当优先服务于教学、方法展示与通用统计建模场景，因此接口需要尽量统一、透明、可解释。

## 2. 设计范围

本次设计只覆盖当前确认的核心功能：

- 输入为 `mice::complete(imp, "long")` 产生的纵向堆叠数据框
- 自动识别 `.imp` 分组，并默认排除 `.imp = 0`
- 使用用户自定义的 `stat_fun()` 计算任意单一数值统计量
- 在每个插补数据集内部通过 bootstrap 估计该统计量
- 在插补数据集之间通过 Rubin 法则合并
- 最终输出 Rubin t 区间
- 自由度采用 Barnard-Rubin 调整形式

本次设计暂不包含以下扩展功能：

- 同时合并多个参数
- cluster bootstrap、stratified bootstrap、survey bootstrap
- BCa 区间或 percentile 区间
- 直接接收 `mids` 对象的接口
- survey 权重或复杂抽样设计

## 3. 推荐函数名称

建议主函数名称为：

`pool_mi_boot_long()`

该名称直观表达了 3 个核心动作：

- `mi`：多重插补结果输入
- `boot`：插补内不确定性来自 bootstrap
- `long`：输入是 `complete(..., "long")` 产生的长表

## 4. 输入接口设计

建议函数接口包含以下参数：

- `data_long`
  - 类型：`data.frame` 或 `tibble`
  - 含义：由 `mice::complete(imp, "long")` 返回的纵向堆叠完整数据
  - 要求：必须包含 `.imp` 列；若包含 `.imp = 0`，函数默认自动排除

- `conf_level`
  - 类型：数值
  - 默认：`0.95`
  - 含义：置信区间水平

- `n_boot`
  - 类型：整数
  - 默认：建议 `500`
  - 含义：每个插补数据集中的 bootstrap 重复次数

- `stat_fun`
  - 类型：函数
  - 含义：用户自定义统计量函数
  - 要求：输入单个完整数据集，输出长度为 1 的数值

- `resample_fun`
  - 类型：函数或 `NULL`
  - 含义：自定义 bootstrap 抽样函数
  - 默认行为：对当前完整数据集按行进行有放回重抽样

- `seed`
  - 类型：整数或 `NULL`
  - 含义：随机种子

- `show_progress`
  - 类型：逻辑值
  - 含义：是否显示进度条

## 5. 输出结构设计

建议返回一个结构化 `list`，主元素包括：

- `pooled_estimate`
- `pooled_se`
- `conf_low`
- `conf_high`
- `statistic`
- `p_value`
- `df`
- `within_variance`
- `between_variance`
- `total_variance`
- `m`
- `n_boot`
- `per_imputation`

其中 `per_imputation` 建议保留每个插补数据集的中间结果，至少包括：

- `estimate`
- `variance`
- `boot_se`
- `boot_values`
- `n_success`
- `n_failed`

这样可以支持：

- 教学展示每个插补数据集的估计差异
- 检查 bootstrap 是否稳定
- 诊断某个插补数据集是否拟合失败过多
- 后续补充绘图函数或敏感性分析

## 6. 核心计算流程

### 6.1 插补数据层面

设共有 `m` 个插补数据集。

对第 `i` 个插补数据集，执行以下步骤：

1. 从 `data_long` 中按 `.imp` 拆出第 `i` 个完整数据集
2. 在该完整数据集内部进行 `n_boot` 次 bootstrap
3. 每次 bootstrap 都重新抽样，并把样本送入 `stat_fun()`
4. 得到 bootstrap 统计量样本 `Q_i^(1), Q_i^(2), ..., Q_i^(B)`
5. 以 bootstrap 统计量均值作为该插补数据集的点估计
6. 计算该插补数据集内部 bootstrap 标准误

建议定义为：

`Q_i = mean(Q_i^(1), ..., Q_i^(B))`

`U_i = var(Q_i^(1), ..., Q_i^(B))`

`SE_i = sqrt(U_i)`

当前版本不再要求函数知道模型公式、模型对象或参数名称，统计量的定义完全由 `stat_fun()` 决定。

### 6.2 Rubin 合并层面

收集所有插补数据集的：

- 点估计 `Q_1, Q_2, ..., Q_m`
- 组内方差 `U_1, U_2, ..., U_m`

然后按 Rubin 法则合并。

合并点估计：

\[
\bar{Q} = \frac{1}{m}\sum_{i=1}^{m}Q_i
\]

组内方差：

\[
V_W = \frac{1}{m}\sum_{i=1}^{m}SE_i^2

等价地也可写为：

\[
V_W = \frac{1}{m}\sum_{i=1}^{m}U_i
\]
\]

组间方差：

\[
V_B = \frac{1}{m-1}\sum_{i=1}^{m}(Q_i - \bar{Q})^2
\]

总方差：

\[
V_T = V_W + \left(1 + \frac{1}{m}\right)V_B
\]

合并标准误：

\[
SE_{pooled} = \sqrt{V_T}
\]

## 7. 推断与区间

### 7.1 检验统计量

对零假设参数值 `theta_0 = 0`，定义：

\[
t = \frac{\bar{Q}}{SE_{pooled}}
\]

默认使用双侧检验。

### 7.2 自由度

自由度采用 Barnard-Rubin 调整版本。

先计算旧自由度：

\[
df_{old} = (m - 1)\left(1 + \frac{1}{r}\right)^2
\]

其中：

\[
r = \frac{(1 + 1/m)V_B}{V_W}
\]

再计算：

\[
\lambda = \frac{r + 2/(df_{com}+3)}{r+1}
\]

这里 `df_com` 表示完整数据分析下的自由度近似。第一版中建议通过样本量与参数个数构造近似观测自由度。

观测信息自由度采用：

\[
df_{observed} = \frac{(n-k)+1}{(n-k)+3}(n-k)(1-\lambda)
\]

最终调整自由度：

\[
df_{adjusted} = \frac{df_{old} \times df_{observed}}{df_{old} + df_{observed}}
\]

### 7.3 置信区间

最终区间采用 Rubin t 区间：

\[
\bar{Q} \pm t_{df, 1-\alpha/2} \times SE_{pooled}
\]

## 8. 参数提取策略

为了支持“任意统计量”的设定，函数不再内置参数提取逻辑。

推荐设计如下：

- 用户必须提供 `stat_fun`
- `stat_fun` 接收一个完整数据集并返回单个数值
- 函数内部不关心这个数值来自均值差、回归系数、AUC 还是任意自定义统计量

这样可以支持：

- 线性回归系数
- Logistic 回归对数 OR
- Cox 回归对数 HR
- 自定义线性组合参数
- 中位数差、AUC、预测差值等任意用户自定义统计量

该设计是“任意模型”可扩展性的关键。

## 9. Bootstrap 失败处理策略

在 bootstrap 过程中可能出现：

- 重抽样后样本分离
- 模型不收敛
- 某些重抽样样本中目标变量无变异
- 目标参数在局部样本中不存在

第一版建议采用稳健但简单的失败处理策略：

- 每次 bootstrap 拟合放入 `tryCatch()`
- 失败时记录为 `NA`
- 最终仅使用成功的 bootstrap 结果计算 `SE_i`
- 同时记录 `n_success` 与 `n_failed`

需要设置一个最少成功次数阈值，例如：

- 若成功次数小于 `max(30, n_boot * 0.5)`，则发出警告
- 若成功次数为 0，则该插补数据集视为不可用并停止合并

## 10. 第一版默认抽样机制

第一版默认抽样机制建议使用简单行级 bootstrap：

- 从当前插补数据集按行有放回抽样
- 抽取样本量与原数据相同

若用户传入 `resample_fun`，则允许覆盖该行为。

这样做的原因是：

- 对大多数教学和常规模型最易理解
- 代码结构最清晰
- 后续容易扩展到 cluster bootstrap

## 11. 第一版默认自由度近似

由于当前函数只知道统计量值而不知道完整模型结构，第一版建议采用以下实用近似：

- `n` 取当前插补数据集样本量
- `k` 固定按 1 处理，即当前只对单个标量统计量做推断

这意味着第一版更偏向通用统计实现，而不是对每一种模型给出完全专用的自由度定义。

在文档和函数说明中应明确：

- 该自由度实现适用于常见回归建模场景
- 对特殊模型若用户有更严格需求，后续可开放 `df_complete` 或 `df_method` 参数进行覆盖

## 12. 建议实现模块

为了保证代码清晰，建议内部拆成以下辅助函数：

- 一个函数负责默认参数提取
- 一个函数负责单次 bootstrap 重抽样
- 一个函数负责单个插补数据集的 bootstrap 估计
- 一个函数负责 Rubin 合并
- 一个主函数负责参数检查、调度和结果整合

建议的内部函数命名示意：

- `validate_long_input()`
- `split_long_by_imp()`
- `resample_rows_default()`
- `estimate_one_imputation_boot()`
- `rubin_pool_scalar()`
- `pool_mi_boot_long()`

## 13. 测试与验证建议

第一版实现后应至少验证以下情形：

- `stat_fun()` 计算简单均值差
- `stat_fun()` 计算回归系数
- bootstrap 中少量失败但总体可用
- `.imp = 0` 时能够自动排除
- 插补数 `m >= 2` 时能正常合并
- `n_boot` 较小时仍能给出合理警告

还建议用一个可手算的小示例核对：

- 每个插补数据集 `theta_i`
- 每个插补数据集 `SE_i`
- `V_W`
- `V_B`
- `V_T`
- `SE_pooled`
- `df`
- 置信区间

## 14. 不做项说明

本次实现不尝试解决以下问题：

- Rubin 法则对非正态统计量的变换问题
- bootstrap 百分位区间与 Rubin 区间的混合定义
- 与所有建模生态的完全无缝兼容
- 所有小样本或边界情形下的最优推断

本次目标是得到一个：

- 通用
- 可读
- 教学友好
- 对常见回归模型适用
- 方便后续扩展

的第一版函数实现。

## 15. 最终结论

本函数的最终设计为：

- 主入口采用 `data_long + n_boot + stat_fun + seed + show_progress`
- 输入数据来自 `mice::complete(imp, "long")`
- 函数内部按 `.imp` 自动拆分完整数据集，并默认排除 `.imp = 0`
- 每个插补数据集内部使用 bootstrap 参数均值作为 `Q_i`，并用 bootstrap 估计 `SE_i`
- 跨插补数据集使用 Rubin 法则合并 `Q_i` 与 `SE_i`
- 最终使用 Barnard-Rubin 调整自由度构造 Rubin t 区间

该方案在“通用性、可解释性、教学适配性”之间取得了最合理的平衡，适合作为第一版正式实现方案。
