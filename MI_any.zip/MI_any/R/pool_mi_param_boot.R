# 载入当前实现依赖的 tidyverse 组件。
suppressPackageStartupMessages({
  library(dplyr)
  library(purrr)
  library(tibble)
})

# 定义空值回退运算符；当左侧对象为 NULL 时返回右侧对象。
`%||%` <- function(x, y) {
  # 如果左侧对象为 NULL，则返回右侧备用对象。
  if (is.null(x)) {
    return(y)
  }

  # 否则直接返回左侧对象。
  x
}

# 校验 long 数据输入是否合法。
validate_long_input <- function(data_long) {
  # 检查输入是否为 data.frame 或 tibble。
  if (!inherits(data_long, c("data.frame", "tbl_df"))) {
    stop("`data_long` 必须是 data.frame 或 tibble。", call. = FALSE)
  }

  # 检查 `.imp` 列是否存在。
  if (!(".imp" %in% names(data_long))) {
    stop("`data_long` 必须包含 `.imp` 列。", call. = FALSE)
  }

  # 检查 `.imp` 列是否可以解释为数值。
  if (!is.numeric(data_long$.imp) && !is.integer(data_long$.imp)) {
    stop("`.imp` 列必须是数值型或整型。", call. = FALSE)
  }

  # 若输入合法则原样返回，便于管道继续使用。
  data_long
}

# 将 long 数据按 `.imp` 拆分成完整数据集列表，并自动排除 `.imp = 0`。
split_long_by_imp <- function(data_long) {
  # 先排除 `.imp = 0` 的原始未插补数据，再按 `.imp` 分组拆分。
  completed_list <- data_long |>
    dplyr::filter(.data$.imp > 0) |>
    dplyr::group_split(.data$.imp, .keep = TRUE)

  # 如果排除后没有至少两个插补数据集，则无法继续 Rubin 合并。
  if (length(completed_list) < 2) {
    stop("排除 `.imp = 0` 后，至少需要 2 个插补数据集。", call. = FALSE)
  }

  # 返回完整数据集列表。
  completed_list
}

# 定义默认的行级 bootstrap 抽样函数。
resample_rows_default <- function(data) {
  # 使用 dplyr 的切片抽样，对当前数据集进行有放回重抽样。
  data |>
    dplyr::slice_sample(n = nrow(data), replace = TRUE)
}

# 对单个插补数据集执行 bootstrap，并计算点估计和组内方差。
estimate_one_imputation_boot <- function(data,
                                         n_boot,
                                         stat_fun,
                                         resample_fun = NULL,
                                         min_success = NULL) {
  # 若用户未指定抽样函数，则使用默认行抽样函数。
  sampler <- resample_fun %||% resample_rows_default

  # 逐次 bootstrap 计算感兴趣的统计量；失败时记为 NA。
  boot_values <- purrr::map_dbl(
    seq_len(n_boot),
    function(i) {
      tryCatch(
        {
          sampled_data <- sampler(data)
          stat_fun(sampled_data)
        },
        error = function(e) {
          NA_real_
        }
      )
    }
  )

  # 提取成功得到的 bootstrap 数值。
  boot_values_ok <- boot_values[is.finite(boot_values)]

  # 统计成功和失败次数。
  n_success <- length(boot_values_ok)
  n_failed <- sum(!is.finite(boot_values))

  # 设定最少成功次数阈值。
  min_success <- min_success %||% max(30L, ceiling(n_boot * 0.5))

  # 若全部失败，则无法继续。
  if (n_success == 0L) {
    stop("某个插补数据集的 bootstrap 全部失败，无法继续合并。", call. = FALSE)
  }

  # 若成功次数过少，则给出警告。
  if (n_success < min_success) {
    warning(
      sprintf(
        "某个插补数据集 bootstrap 成功次数仅为 %s，低于阈值 %s，结果可能不稳定。",
        n_success,
        min_success
      ),
      call. = FALSE
    )
  }

  # 计算 bootstrap 均值作为该插补数据集的点估计。
  estimate <- mean(boot_values_ok)

  # 计算 bootstrap 方差作为该插补数据集的组内方差。
  variance <- stats::var(boot_values_ok)

  # 计算 bootstrap 标准误。
  boot_se <- sqrt(variance)

  # 若点估计不是有限值，则报错。
  if (!is.finite(estimate)) {
    stop("无法从 bootstrap 结果计算有限点估计。", call. = FALSE)
  }

  # 若方差不是有限值，则报错。
  if (!is.finite(variance)) {
    stop("无法从 bootstrap 结果计算有限方差。", call. = FALSE)
  }

  # 返回当前插补数据集的中间结果。
  tibble::tibble(
    .imp = dplyr::first(data$.imp),
    estimate = estimate,
    variance = variance,
    boot_se = boot_se,
    boot_values = list(boot_values),
    n_success = n_success,
    n_failed = n_failed
  )
}

# 对多个插补数据集的标量统计量执行 Rubin 合并。
rubin_pool_scalar <- function(estimates,
                              variances,
                              conf_level = 0.95,
                              n,
                              k = 1) {
  # 计算插补数据集个数。
  m <- length(estimates)

  # 计算合并点估计。
  pooled_estimate <- mean(estimates)

  # 计算组内方差。
  within_variance <- mean(variances)

  # 计算组间方差。
  between_variance <- stats::var(estimates)

  # 计算总方差。
  total_variance <- within_variance + (1 + 1 / m) * between_variance

  # 计算合并标准误。
  pooled_se <- sqrt(total_variance)

  # 计算完整数据近似自由度。
  df_complete <- max(as.numeric(n - k), 1)

  # 计算相对方差增加量。
  if (isTRUE(all.equal(within_variance, 0))) {
    if (isTRUE(all.equal(between_variance, 0))) {
      r <- 0
    } else {
      r <- Inf
    }
  } else {
    r <- ((1 + 1 / m) * between_variance) / within_variance
  }

  # 计算旧自由度。
  if (is.infinite(r)) {
    df_old <- m - 1
  } else if (isTRUE(all.equal(r, 0))) {
    df_old <- Inf
  } else {
    df_old <- (m - 1) * (1 + 1 / r)^2
  }

  # 计算缺失信息比例近似值 lambda。
  lambda <- (r + 2 / (df_complete + 3)) / (r + 1)
  lambda <- min(max(lambda, 0), 1)

  # 计算观测信息自由度。
  df_observed <- ((df_complete + 1) / (df_complete + 3)) * df_complete * (1 - lambda)

  # 计算 Barnard-Rubin 调整自由度。
  if (is.infinite(df_old)) {
    df <- df_observed
  } else {
    df <- (df_old * df_observed) / (df_old + df_observed)
  }

  # 若自由度无效，则退化为无穷大近似。
  if (!is.finite(df) || df <= 0) {
    df <- Inf
  }

  # 计算显著性水平 alpha。
  alpha <- 1 - conf_level

  # 计算 t 分布临界值。
  t_crit <- stats::qt(1 - alpha / 2, df = df)

  # 计算检验统计量。
  statistic <- pooled_estimate / pooled_se

  # 计算双侧 p 值。
  p_value <- 2 * stats::pt(abs(statistic), df = df, lower.tail = FALSE)

  # 返回合并结果。
  list(
    pooled_estimate = pooled_estimate,
    pooled_se = pooled_se,
    conf_low = pooled_estimate - t_crit * pooled_se,
    conf_high = pooled_estimate + t_crit * pooled_se,
    statistic = statistic,
    p_value = p_value,
    df = df,
    within_variance = within_variance,
    between_variance = between_variance,
    total_variance = total_variance,
    relative_increase_in_variance = r,
    lambda = lambda
  )
}

# 主函数：接收 mice::complete(..., "long") 输出的 long 数据并执行合并。
pool_mi_boot_long <- function(data_long,
                              n_boot,
                              stat_fun,
                              seed = NULL,
                              show_progress = TRUE,
                              conf_level = 0.95,
                              resample_fun = NULL) {
  # 检查自定义统计量函数是否合法。
  if (!is.function(stat_fun)) {
    stop("`stat_fun` 必须是函数。", call. = FALSE)
  }

  # 检查 bootstrap 次数是否合法。
  if (!is.numeric(n_boot) || length(n_boot) != 1L || is.na(n_boot) || n_boot < 2) {
    stop("`n_boot` 必须是不小于 2 的单个数值。", call. = FALSE)
  }

  # 检查置信水平是否合法。
  if (!is.numeric(conf_level) || length(conf_level) != 1L ||
      is.na(conf_level) || conf_level <= 0 || conf_level >= 1) {
    stop("`conf_level` 必须是位于 0 和 1 之间的单个数值。", call. = FALSE)
  }

  # 检查抽样函数是否为函数或 NULL。
  if (!is.null(resample_fun) && !is.function(resample_fun)) {
    stop("`resample_fun` 必须是函数或 NULL。", call. = FALSE)
  }

  # 将 bootstrap 次数强制转为整数。
  n_boot <- as.integer(n_boot)

  # 检查是否需要设置随机种子。
  if (!is.null(seed)) {
    set.seed(seed)
  }

  # 校验 long 数据输入。
  data_long_checked <- validate_long_input(data_long)

  # 按 `.imp` 拆分完整数据集。
  completed_list <- split_long_by_imp(data_long_checked)

  # 如果用户要求显示进度条，则初始化文本进度条。
  pb <- NULL
  if (isTRUE(show_progress)) {
    pb <- utils::txtProgressBar(
      min = 0,
      max = length(completed_list),
      initial = 0,
      style = 3
    )
    on.exit(close(pb), add = TRUE)
  }

  # 对每个插补数据集执行 bootstrap。
  per_imputation_tbl <- purrr::imap(
    completed_list,
    function(dat_one, idx) {
      # 若启用进度条，则更新当前进度。
      if (!is.null(pb)) {
        utils::setTxtProgressBar(pb, value = idx)
      }

      estimate_one_imputation_boot(
        data = dat_one,
        n_boot = n_boot,
        stat_fun = stat_fun,
        resample_fun = resample_fun
      )
    }
  ) |>
    dplyr::bind_rows()

  # 提取点估计向量。
  estimates <- per_imputation_tbl |>
    dplyr::pull(.data$estimate)

  # 提取组内方差向量。
  variances <- per_imputation_tbl |>
    dplyr::pull(.data$variance)

  # 提取样本量 n；使用第一个完整数据集的行数近似。
  n <- completed_list |>
    purrr::pluck(1) |>
    nrow()

  # 执行 Rubin 合并。
  pooled <- rubin_pool_scalar(
    estimates = estimates,
    variances = variances,
    conf_level = conf_level,
    n = n,
    k = 1
  )

  # 返回最终结果。
  c(
    pooled,
    list(
      m = length(completed_list),
      n_boot = n_boot,
      per_imputation = split(per_imputation_tbl, seq_len(nrow(per_imputation_tbl)))
    )
  )
}
