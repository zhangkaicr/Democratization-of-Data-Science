# 载入主函数文件。
source("R/pool_mi_param_boot.R")
# 载入 mice 包以生成多重插补后的 long 数据。
library(mice)

# 固定随机种子以便结果可复现。
set.seed(42)

# 设定样本量。
n <- 100

# 构造一个包含缺失值的示例数据。
dat <- data.frame(
  x = rnorm(n),
  z = rnorm(n)
)


# 根据设定模型生成结局变量。
dat$y <- 0.5 + 0.8 * dat$x - 0.3 * dat$z + rnorm(n, sd = 1)

# 随机制造部分缺失值。
dat$x[sample.int(n, size = 15)] <- NA


# 使用 mice 生成多重插补结果。
imp <- mice(dat, m = 5, maxit = 5, printFlag = FALSE, seed = 2026)

# 使用 complete(..., "long") 提取纵向堆叠完整数据。
dat_long <- complete(imp, "long", include = F)
head(dat_long)

# 定义感兴趣统计量函数；这里示例为线性回归中 x 的回归系数。
stat_fun <- function(dat_one) {
  fit <- lm(y ~ x + z, data = dat_one)
  unname(stats::coef(fit)[["x"]])
}

# 调用主函数并合并 bootstrap 后的统计量。
res <- pool_mi_boot_long(
  data_long = dat_long,
  n_boot = 50,
  stat_fun = stat_fun,
  seed = 2026,
  show_progress = FALSE
)

# 输出合并点估计。
print(res$pooled_estimate)

# 输出合并标准误。
print(res$pooled_se)

# 输出置信区间。
print(c(res$conf_low, res$conf_high))




# 使用传统的 mice::with() + mice::pool() 流程拟合同一个线性回归模型。
fit_mice <- with(imp, lm(y ~ x + z))

# 对各插补数据集的模型结果做 Rubin 合并。
pool_mice <- pool(fit_mice)

# 提取传统 mice 流程的汇总结果表。
pool_mice_tbl <- summary(pool_mice, conf.int = TRUE)

# 提取 x 对应的传统 mice 合并结果。
pool_mice_x <- pool_mice_tbl[pool_mice_tbl$term == "x", ]

# 整理本函数结果与传统 mice 流程结果，便于并排对比。
compare_tbl <- data.frame(
  method = c("bootstrap_rubin_long", "mice_with_pool"),
  estimate = c(res$pooled_estimate, pool_mice_x$estimate),
  std_error = c(res$pooled_se, pool_mice_x$std.error),
  conf_low = c(res$conf_low, pool_mice_x$`2.5 %`),
  conf_high = c(res$conf_high, pool_mice_x$`97.5 %`)
)

# 输出两种流程的并排对比表。
print(compare_tbl)
