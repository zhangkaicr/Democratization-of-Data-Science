# 载入主函数文件。
source("R/pool_mi_param_boot.R")

# 载入本示例需要的 R 包。
library(mice)
library(ranger)
library(pROC)

# 固定随机种子，保证示例结果可复现。
set.seed(2026)

# 设定样本量。
n <- 300

# 构造三个连续型预测变量。
dat <- tibble::tibble(
  x1 = rnorm(n),
  x2 = rnorm(n),
  x3 = rnorm(n)
)

# 构造一个带有非线性项和交互项的真实线性预测器。
linpred <- 0.8 * dat$x1 - 0.7 * dat$x2 + 0.6 * dat$x1 * dat$x3 - 0.5 * dat$x2^2

# 将线性预测器转换为二分类结局概率。
prob_yes <- stats::plogis(linpred)

# 依据概率生成二分类结局，并显式设定因子水平顺序。
dat$y <- factor(
  ifelse(stats::runif(n) < prob_yes, "yes", "no"),
  levels = c("no", "yes")
)

# 为预测变量随机制造缺失值，模拟实际数据情境。
dat$x1[sample.int(n, size = 45)] <- NA
dat$x2[sample.int(n, size = 35)] <- NA
dat$x3[sample.int(n, size = 30)] <- NA
head(dat)

# 使用 mice 进行多重插补。
imp <- mice(
  data = as.data.frame(dat),
  m = 5,
  maxit = 5,
  printFlag = FALSE,
  seed = 2026
)

# 将多重插补结果提取为 long 格式数据。
dat_long <- complete(imp, "long", include = F)
head(dat_long) 

# 定义感兴趣统计量函数：
# 输入一个完整数据集，输出该数据集内随机森林模型的 AUC。
stat_fun_auc <- function(dat_one) {
  # 确保结局变量是二分类因子，且水平顺序固定。
  dat_one$y <- factor(dat_one$y, levels = c("no", "yes"))

  # 使用 ranger 拟合二分类随机森林，并要求输出类别概率。
  rf_fit <- ranger::ranger(
    formula = y ~ x1 + x2 + x3,
    data = dat_one,
    probability = TRUE,
    num.trees = 300,
    mtry = 2,
    min.node.size = 5,
    seed = 2026
  )

  # 提取每个样本属于阳性类 yes 的预测概率。
  pred_yes <- rf_fit$predictions[, "yes"]

  # 使用 pROC 计算 AUC，并返回单一数值。
  as.numeric(
    pROC::roc(
      response = dat_one$y,
      predictor = pred_yes,
      levels = c("no", "yes"),
      direction = "<",
      quiet = TRUE
    )$auc
  )
}

# 调用主函数，对多重插补后的 AUC 做 bootstrap + Rubin 合并。
res_auc <- pool_mi_boot_long(
  data_long = dat_long,
  n_boot = 60,
  stat_fun = stat_fun_auc,
  seed = 2026,
  show_progress = FALSE
)

# 输出合并后的 AUC 点估计。
print(res_auc$pooled_estimate)

# 输出合并后的标准误。
print(res_auc$pooled_se)

# 输出合并后的 95% 置信区间。
print(c(res_auc$conf_low, res_auc$conf_high))

# 输出每个插补数据集的中间结果，便于教学展示。
print(res_auc$per_imputation)

sessionInfo()
