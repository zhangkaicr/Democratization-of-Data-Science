# 载入待测试函数文件；此时接口尚未改为 long 版，因此测试应先失败
source("R/pool_mi_param_boot.R")

# 构造一个包含 .imp 的 long 数据，并故意保留 .imp = 0。
long_dat <- data.frame(
  y = c(1, 2, 3, 4, 10, 20, 30, 40, 11, 21, 31, 41),
  grp = c(0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1),
  .imp = c(0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2),
  .id = as.character(rep(1:4, 3))
)

# 定义自定义统计量函数；输入单个完整数据集，输出均值差。
stat_fun <- function(dat) {
  mean(dat$y[dat$grp == 1]) - mean(dat$y[dat$grp == 0])
}

# 运行主函数。
res <- pool_mi_boot_long(
  data_long = long_dat,
  n_boot = 20,
  stat_fun = stat_fun,
  seed = 2026,
  show_progress = FALSE
)

# 基本结构断言
stopifnot(is.list(res))
stopifnot(all(c(
  "pooled_estimate",
  "pooled_se",
  "conf_low",
  "conf_high",
  "within_variance",
  "between_variance",
  "total_variance",
  "per_imputation"
) %in% names(res)))

# 数值关系断言
stopifnot(length(res$per_imputation) == 2)
stopifnot(is.finite(res$pooled_estimate))
stopifnot(is.finite(res$pooled_se))
stopifnot(res$total_variance >= res$within_variance)
stopifnot(res$conf_low <= res$pooled_estimate)
stopifnot(res$conf_high >= res$pooled_estimate)

# 检查缺失 .imp 列时，函数会显式报错。
error_caught <- FALSE

# 使用 tryCatch 捕获预期错误。
tryCatch(
  {
    pool_mi_boot_long(
      data_long = data.frame(y = 1:4),
      n_boot = 20,
      stat_fun = stat_fun,
      show_progress = FALSE
    )
  },
  error = function(e) {
    error_caught <<- TRUE
  }
)

# 断言缺失 .imp 列确实会触发错误。
stopifnot(isTRUE(error_caught))

# 构造一个确定性 long 数据，用于验证 `.imp = 0` 被排除且点估计使用 bootstrap 均值。
det_long <- data.frame(
  x = c(9, 9, 10, 20, 100, 200),
  .imp = c(0, 0, 1, 1, 2, 2),
  .id = c("1", "2", "1", "2", "1", "2")
)

# 定义简单统计量函数；返回 x 的均值。
det_stat_fun <- function(dat) {
  mean(dat$x)
}

# 用环境记录每个插补数据集当前是第几次 bootstrap。
det_env <- new.env(parent = emptyenv())
det_env$count_1 <- 0L
det_env$count_2 <- 0L

# 自定义 bootstrap 抽样函数；按预设序列返回样本，确保期望值可手工计算。
det_resample_fun <- function(data) {
  if (data$.imp[1] == 1) {
    det_env$count_1 <- det_env$count_1 + 1L
    if (det_env$count_1 == 1L) {
      return(data.frame(x = c(0, 0), .imp = c(1, 1), .id = c("1", "2")))
    }
    return(data.frame(x = c(10, 10), .imp = c(1, 1), .id = c("1", "2")))
  }

  det_env$count_2 <- det_env$count_2 + 1L
  if (det_env$count_2 == 1L) {
    return(data.frame(x = c(20, 20), .imp = c(2, 2), .id = c("1", "2")))
  }
  data.frame(x = c(40, 40), .imp = c(2, 2), .id = c("1", "2"))
}

# 运行主函数；按照新逻辑，每个插补数据集的点估计应为 bootstrap 样本均值。
det_res <- pool_mi_boot_long(
  data_long = det_long,
  n_boot = 2,
  stat_fun = det_stat_fun,
  resample_fun = det_resample_fun,
  show_progress = FALSE
)

# 第一个插补数据集的 bootstrap 均值应为 (0 + 10) / 2 = 5。
stopifnot(isTRUE(all.equal(det_res$per_imputation[[1]]$estimate, 5)))

# 第二个插补数据集的 bootstrap 均值应为 (20 + 40) / 2 = 30。
stopifnot(isTRUE(all.equal(det_res$per_imputation[[2]]$estimate, 30)))

# 总点估计应等于两个插补数据集 bootstrap 均值的平均数 17.5。
stopifnot(isTRUE(all.equal(det_res$pooled_estimate, 17.5)))

cat("test_pool_mi_boot_long: PASS\n")
